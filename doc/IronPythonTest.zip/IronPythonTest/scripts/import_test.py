print 'importing foo'
import foo
print 'result of foo.do_math(1,2): %s' % foo.do_math(1,2); 