import logging
import traceback

import sys

def foo():
   1/0

logger = logging.getLogger("foo")


print globals().keys()
print sys.version

try:
   logger.info("entering foo ...")
   foo()
except Exception, e:
   logger.exception("UH OH!")   
   raise   
