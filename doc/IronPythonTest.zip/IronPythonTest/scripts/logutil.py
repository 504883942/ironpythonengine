import logging
import os

class CSharpListHandler(logging.Handler):

    def __init__(self, the_list):
        logging.Handler.__init__(self)
        self.the_list = the_list

    def emit(self, record):
        msg = self.format(record)
        self.the_list.Add(msg)


def logging_setup(the_list):
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    handler = CSharpListHandler(the_list)
    FORMAT = "%(name)s\t%(levelname)s\t%(asctime)s\t%(message)s"
    handler.setFormatter(logging.Formatter(FORMAT))
    logger.addHandler(handler)

    #security concerns do not allow the logging library to obtain the PID
    #however, we cannot stop the logging module from trying, so we fake it out
    def getpid():
        return -9999
    os.getpid = getpid
