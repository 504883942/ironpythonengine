def do_math(a,b):
    return a+b