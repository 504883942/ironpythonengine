﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Security.Policy;
using System.Security.Permissions;
using System.Security;
using System.IO;
using Microsoft.Scripting.Hosting;
using IronPython.Hosting;
using System.Runtime.Remoting;
using System.Net;

namespace python_in_appdomain
{
    [Serializable]
    public class Whatever
    {
        public int i;
        public Whatever(int i)
        {
            this.i = i;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {

            string path = @"C:\Users\m308027\Documents\Visual Studio 2010\Projects\IronPythonTest\scripts";
            string std_lib = @"C:\Python26\Lib";
            
            //run_script(Path.Combine(path, "import_test.py"), new string[]{path}); //standard importing
            //run_script(Path.Combine(path, "import_test.py"), new string[] { });   //standard importing with no file access

            run_script(Path.Combine(path, "use_std_lib.py"), new string[] { path, std_lib }, true);       //using the standard library
            run_script(Path.Combine(path, "use_std_lib.py"), new string[] { path, std_lib }, false);       //using the standard library
            //run_script(Path.Combine(path, "use_std_lib.py"), new string[] { });                           //using the standard library with no file access

            Console.ReadLine();
        }


        static void run_script(string script_path, string[] search_paths, bool restricted=false)
        {
            Console.WriteLine("------------{0}------------------",  script_path);
            Console.WriteLine("Search Paths: {0}", String.Join(",", search_paths));
            Console.WriteLine("Restricted = {0}", restricted);


            string script = File.ReadAllText(script_path);
            Whatever w = new Whatever(2);
            IronPythonEngine ipe = new IronPythonEngine(restricted, search_paths);

            ipe.scope.SetVariable("w", w);
            //Console.WriteLine(w.i);
            try
            {



                Console.WriteLine("******************");
                string s = ipe.run_script<string>(@" 
def do_something():
    return 'hello'
do_something()
");
                Console.WriteLine(s);

                int x = ipe.run_script<int>(@"
def do_whatever():
    return 3+6

do_whatever()
");

                Whatever w1 = ipe.run_script<Whatever>(@" 
def do_something_else():
    w.i = 54
    return 4
do_something_else()
");

                Console.WriteLine(w1.i);
                
                Console.WriteLine("******************");

                ipe.run_script(script);
            
            }
            catch (SecurityException e)
            {

                Console.WriteLine("Experienced Security Violation while running script.  The following permission is required:\n{0}", e.Demanded.ToString());
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Experienced Exception while running script:\n{0}", e.Message);
            }
            w = ipe.scope.GetVariable<Whatever>("w");
            //Console.WriteLine(w.i);
            Console.WriteLine("*****Logs from script*****");
            foreach (string log in ipe.get_logs())
            {
                Console.WriteLine(log);
            }
        }

    }
}