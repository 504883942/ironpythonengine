﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//security
using System.Security.Policy;
using System.Security.Permissions;
using System.Security;
using System.IO;
//IronPython and hosting
using Microsoft.Scripting.Hosting;
using IronPython.Hosting;
using System.Runtime.Serialization;
using IronPython.Runtime.Exceptions;

namespace python_in_appdomain
{

    class IronPythonException : Exception, ISerializable {
        public IronPythonException() : base() { }
        public IronPythonException(string message) : base(message) { }
        public IronPythonException(string message, Exception inner) : base(message, inner) { }
    }



    class IronPythonEngine
    {

            protected AppDomain domain;
            
            protected ScriptRuntime py;
            public ScriptEngine engine;
            public ScriptScope scope;

            protected List<string> logs;

            //in reality, this would be four classes:
            //Some kind of script runner.  This would be responsible for setting up logging, accepting scripts, exposing the scope, etc ...
            //An Abstract Engine class that is responsible for instantiating the Engine/Runtime/Scope.  These would be provided to the script runner 
            //    - A subclass that is a restricted engine (would take acceptable folders)
            //    - A subclass that is unrestricted

            //logging script would be included as a resource.
            public IronPythonEngine(bool restricted, string[] dir_paths = null){
                if (dir_paths.Length == 0)
                    dir_paths = null;
                this.logs = new List<string>();

                if (restricted == true)
                {
                    this.create_restricted_engine(dir_paths);
                }
                else
                {
                    this.create_unrestricted_engine();
                }

                if(dir_paths != null){
                    this.engine.SetSearchPaths(dir_paths);
                }

                

                //consider having this as part of the class / a reference (so that we don't have to rely on the users script directory having it).
                string log_script = System.Text.Encoding.UTF8.GetString(IronPythonTest.Properties.Resources.logutil); 
                this.scope.SetVariable("log_list", this.logs);
                this.run_script(log_script);

            }

            protected void create_unrestricted_engine()
            {
                this.engine = Python.CreateEngine();
                this.py = this.engine.Runtime;
                this.scope = this.engine.CreateScope();
            }

            protected void create_restricted_engine(string[] dir_paths)
            {
                //consider adding the ability to add permissions as necessary.
                PermissionSet pset = new PermissionSet(PermissionState.None);
                pset.AddPermission(new SecurityPermission(SecurityPermissionFlag.Execution));
                pset.AddPermission(new ReflectionPermission(PermissionState.Unrestricted));

                if (dir_paths != null)
                {
                    pset.AddPermission(new FileIOPermission(FileIOPermissionAccess.Read | FileIOPermissionAccess.PathDiscovery, dir_paths));
                }

                AppDomainSetup setup = new AppDomainSetup();
                setup.ApplicationBase = System.Environment.CurrentDirectory;
                this.domain = AppDomain.CreateDomain("IPyEngine", new Evidence(), setup, pset);

                this.py = Python.CreateRuntime(domain);
                this.engine = this.py.GetEngine("py");
                this.scope = this.engine.CreateScope();
            }


            public string[] get_logs()
            {
                return this.logs.ToArray();
            }
            public void clear_logs()
            {
                this.logs.Clear();
            }

            public void run_script(string script, bool catch_exception=false){
                try
                {
                    this.engine.CreateScriptSourceFromString(script).Execute(this.scope);
                }
                catch (Exception e)
                {
                    //security nonsense
                    this.logs = this.scope.GetVariable<List<string>>("log_list");
                    throw new IronPythonException(this.engine.GetService<ExceptionOperations>().FormatException(e));
                }
           }

            public T run_script<T>(string script)
            {
                return this.engine.Execute<T>(script, this.scope);
            }

    }
}
